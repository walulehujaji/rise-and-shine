# 🌟 RISE AND SHINE – Flutter App

## Bet Smart. Win Better.

---

## 📲 HOW TO BUILD YOUR APK (From Phone Using Codemagic)

### STEP 1 — Set Up Firebase
1. Go to https://console.firebase.google.com
2. Click "Add project" → name it "rise-and-shine"
3. Add an Android app → package name: `com.riseandshine.app`
4. Download the real `google-services.json`
5. Replace the placeholder `android/app/google-services.json` with your real file

### STEP 2 — Upload to GitHub
1. Go to https://github.com → Create new repository → name: `rise-and-shine`
2. Upload ALL these files keeping the same folder structure
3. Commit and push

### STEP 3 — Build on Codemagic
1. Go to https://codemagic.io
2. Sign in with GitHub
3. Select your `rise-and-shine` repository
4. Choose "Flutter App" workflow
5. Click START BUILD
6. Wait ~10 minutes → download your APK ✅

### STEP 4 — Upload to Google Play
1. Go to https://play.google.com/console
2. Create developer account ($25 one-time fee)
3. Create new app → upload your APK
4. Fill in store listing → publish!

---

## 🔥 Firebase Firestore Structure

Create these collections in Firebase:

### `tips` collection
Each document:
```
{
  match: "Man City vs Arsenal",
  league: "Premier League",
  sport: "⚽",
  prediction: "Both Teams to Score",
  odds: "1.85",
  result: "win",       // "win" | "loss" | "pending"
  premium: false       // true = locked for free users
}
```

### `users` collection
Each document (auto-created on register):
```
{
  email: "user@email.com",
  paid: false,         // set to true to give PRO access
  createdAt: timestamp
}
```

To activate a user's PRO:
→ Go to Firebase Console → Firestore → users → find user doc → set `paid: true`

---

## 📁 Project Structure
```
rise_and_shine/
├── lib/
│   └── main.dart           ← Full app code
├── android/
│   ├── app/
│   │   ├── build.gradle
│   │   ├── google-services.json  ← Replace with real one!
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── kotlin/com/riseandshine/app/MainActivity.kt
│   │       └── res/
│   ├── build.gradle
│   └── settings.gradle
├── pubspec.yaml
├── codemagic.yaml
└── README.md
```

---

## ✅ Features
- 🔐 Login & Register with Firebase Auth
- 🏠 Home screen with live tips from Firestore
- 🔒 Premium tips locked for free users
- 💳 Payment instructions bottom sheet
- ⭐ PRO badge for paid users
- 📊 Live stats (wins, pending, win rate)
- 🎨 Beautiful dark gold theme
