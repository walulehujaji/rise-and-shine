import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  await Firebase.initializeApp();
  runApp(const MyApp());
}

// ── COLORS ──────────────────────────────────────────────
const kDark = Color(0xFF0A0A0F);
const kDark2 = Color(0xFF12121A);
const kDark3 = Color(0xFF1A1A28);
const kCard = Color(0xFF16161F);
const kGold = Color(0xFFFFD700);
const kGold2 = Color(0xFFFFA500);
const kText = Color(0xFFE8E8F0);
const kMuted = Color(0xFF7A7A9A);
const kGreen = Color(0xFF00E676);
const kRed = Color(0xFFFF4444);

// ── APP ──────────────────────────────────────────────────
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rise and Shine',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: kDark,
        colorScheme: const ColorScheme.dark(
          primary: kGold,
          secondary: kGold2,
          surface: kCard,
        ),
        textTheme: GoogleFonts.barlowTextTheme(ThemeData.dark().textTheme),
        useMaterial3: true,
      ),
      home: const AuthWrapper(),
    );
  }
}

// ── AUTH WRAPPER ─────────────────────────────────────────
class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const SplashScreen();
        }
        if (snapshot.hasData) return const HomeScreen();
        return const LoginScreen();
      },
    );
  }
}

// ── SPLASH ───────────────────────────────────────────────
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kDark,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('☀️', style: TextStyle(fontSize: 64)),
            const SizedBox(height: 16),
            Text(
              'RISE AND SHINE',
              style: GoogleFonts.blackOpsOne(
                fontSize: 32,
                letterSpacing: 3,
                foreground: Paint()
                  ..shader = const LinearGradient(
                    colors: [kGold, kGold2],
                  ).createShader(const Rect.fromLTWH(0, 0, 300, 50)),
              ),
            ),
            const SizedBox(height: 24),
            const CircularProgressIndicator(color: kGold),
          ],
        ),
      ),
    );
  }
}

// ── LOGIN SCREEN ─────────────────────────────────────────
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _isLogin = true;
  bool _loading = false;
  bool _obscure = true;
  String _error = '';
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _animCtrl.forward();
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _animCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() { _error = ''; _loading = true; });
    try {
      if (_isLogin) {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: _emailCtrl.text.trim(),
          password: _passCtrl.text.trim(),
        );
      } else {
        final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: _emailCtrl.text.trim(),
          password: _passCtrl.text.trim(),
        );
        // Create user doc
        await FirebaseFirestore.instance
            .collection('users')
            .doc(cred.user!.uid)
            .set({'email': _emailCtrl.text.trim(), 'paid': false, 'createdAt': FieldValue.serverTimestamp()});
      }
    } on FirebaseAuthException catch (e) {
      setState(() => _error = _friendlyError(e.code));
    } catch (e) {
      setState(() => _error = 'Something went wrong. Try again.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _friendlyError(String code) {
    switch (code) {
      case 'user-not-found': return 'No account found with this email.';
      case 'wrong-password': return 'Incorrect password. Try again.';
      case 'email-already-in-use': return 'Account already exists. Please login.';
      case 'invalid-email': return 'Enter a valid email address.';
      case 'weak-password': return 'Password must be at least 6 characters.';
      default: return 'Authentication failed. Try again.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kDark,
      body: FadeTransition(
        opacity: _fadeAnim,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 40),
                // LOGO
                const Text('☀️', style: TextStyle(fontSize: 60)),
                const SizedBox(height: 12),
                ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    colors: [kGold, kGold2, kGold],
                  ).createShader(bounds),
                  child: Text(
                    'RISE AND SHINE',
                    style: GoogleFonts.blackOpsOne(
                      fontSize: 30,
                      letterSpacing: 3,
                      color: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'BET SMART. WIN BETTER.',
                  style: GoogleFonts.barlowCondensed(
                    fontSize: 13,
                    letterSpacing: 5,
                    color: kMuted,
                  ),
                ),
                const SizedBox(height: 40),

                // CARD
                Container(
                  decoration: BoxDecoration(
                    color: kCard,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: kGold.withOpacity(0.15)),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 40, offset: const Offset(0, 20))],
                  ),
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      // TABS
                      Container(
                        decoration: BoxDecoration(color: kDark3, borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.all(4),
                        child: Row(
                          children: [
                            _tab('Login', _isLogin, () => setState(() { _isLogin = true; _error = ''; })),
                            _tab('Register', !_isLogin, () => setState(() { _isLogin = false; _error = ''; })),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // EMAIL
                      _field('Email Address', _emailCtrl, false, TextInputType.emailAddress),
                      const SizedBox(height: 16),

                      // PASSWORD
                      TextField(
                        controller: _passCtrl,
                        obscureText: _obscure,
                        keyboardType: TextInputType.visiblePassword,
                        style: const TextStyle(color: kText, fontSize: 15),
                        decoration: InputDecoration(
                          labelText: 'Password',
                          labelStyle: GoogleFonts.barlowCondensed(color: kMuted, letterSpacing: 2, fontSize: 12),
                          filled: true,
                          fillColor: kDark3,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: kGold.withOpacity(0.15))),
                          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: kGold.withOpacity(0.15))),
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: kGold.withOpacity(0.5))),
                          suffixIcon: IconButton(
                            icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility, color: kMuted, size: 20),
                            onPressed: () => setState(() => _obscure = !_obscure),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // BUTTON
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(colors: [kGold, kGold2]),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [BoxShadow(color: kGold.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 6))],
                          ),
                          child: ElevatedButton(
                            onPressed: _loading ? null : _submit,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            child: _loading
                                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                                : Text(
                                    _isLogin ? 'LOGIN' : 'REGISTER',
                                    style: GoogleFonts.blackOpsOne(fontSize: 16, letterSpacing: 2, color: Colors.black),
                                  ),
                          ),
                        ),
                      ),

                      if (_error.isNotEmpty) ...[
                        const SizedBox(height: 14),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: kRed.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: kRed.withOpacity(0.3)),
                          ),
                          child: Text(_error, style: const TextStyle(color: kRed, fontSize: 13), textAlign: TextAlign.center),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _tab(String label, bool active, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            gradient: active ? const LinearGradient(colors: [kGold, kGold2]) : null,
            borderRadius: BorderRadius.circular(9),
            boxShadow: active ? [BoxShadow(color: kGold.withOpacity(0.3), blurRadius: 12)] : null,
          ),
          child: Text(
            label.toUpperCase(),
            textAlign: TextAlign.center,
            style: GoogleFonts.barlowCondensed(
              fontSize: 14,
              letterSpacing: 3,
              fontWeight: FontWeight.w700,
              color: active ? Colors.black : kMuted,
            ),
          ),
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController ctrl, bool obscure, TextInputType type) {
    return TextField(
      controller: ctrl,
      obscureText: obscure,
      keyboardType: type,
      style: const TextStyle(color: kText, fontSize: 15),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: GoogleFonts.barlowCondensed(color: kMuted, letterSpacing: 2, fontSize: 12),
        filled: true,
        fillColor: kDark3,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: kGold.withOpacity(0.15))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: kGold.withOpacity(0.15))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: kGold.withOpacity(0.5))),
      ),
    );
  }
}

// ── HOME SCREEN ───────────────────────────────────────────
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _user = FirebaseAuth.instance.currentUser;

  Future<bool> _checkPaid() async {
    if (_user == null) return false;
    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(_user!.uid).get();
      if (!doc.exists) return false;
      return doc.data()?['paid'] ?? false;
    } catch (_) {
      return false;
    }
  }

  void _showPayment(BuildContext ctx) {
    showModalBottomSheet(
      context: ctx,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const PaymentSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kDark,
      appBar: AppBar(
        backgroundColor: kDark2,
        elevation: 0,
        title: ShaderMask(
          shaderCallback: (b) => const LinearGradient(colors: [kGold, kGold2]).createShader(b),
          child: Text('RISE & SHINE', style: GoogleFonts.blackOpsOne(fontSize: 20, letterSpacing: 2, color: Colors.white)),
        ),
        actions: [
          FutureBuilder<bool>(
            future: _checkPaid(),
            builder: (_, snap) {
              if (snap.data == true) {
                return Container(
                  margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [kGold, kGold2]),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Center(
                    child: Text('⭐ PRO', style: GoogleFonts.barlowCondensed(fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.w700, color: Colors.black)),
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),
          IconButton(
            icon: const Icon(Icons.power_settings_new, color: kMuted),
            onPressed: () => FirebaseAuth.instance.signOut(),
          ),
        ],
      ),
      body: FutureBuilder<bool>(
        future: _checkPaid(),
        builder: (ctx, paidSnap) {
          if (!paidSnap.hasData) {
            return const Center(child: CircularProgressIndicator(color: kGold));
          }
          final isPaid = paidSnap.data!;
          return _buildBody(ctx, isPaid);
        },
      ),
      floatingActionButton: FutureBuilder<bool>(
        future: _checkPaid(),
        builder: (ctx, snap) {
          if (snap.data == true) return const SizedBox.shrink();
          return FloatingActionButton.extended(
            onPressed: () => _showPayment(ctx),
            backgroundColor: kGold,
            foregroundColor: Colors.black,
            icon: const Icon(Icons.lock_open),
            label: Text('Unlock PRO', style: GoogleFonts.blackOpsOne(fontSize: 13, letterSpacing: 1)),
          );
        },
      ),
    );
  }

  Widget _buildBody(BuildContext ctx, bool isPaid) {
    return CustomScrollView(
      slivers: [
        // HERO
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  DateFormat('EEEE, MMMM d yyyy').format(DateTime.now()).toUpperCase(),
                  style: GoogleFonts.barlowCondensed(fontSize: 11, letterSpacing: 4, color: kGold2),
                ),
                const SizedBox(height: 4),
                RichText(
                  text: TextSpan(
                    style: GoogleFonts.barlowCondensed(fontSize: 26, fontWeight: FontWeight.w700, color: kText),
                    children: const [
                      TextSpan(text: "Today's "),
                      TextSpan(text: "Predictions", style: TextStyle(color: kGold)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),

        // STATS ROW
        SliverToBoxAdapter(child: _statsRow()),

        // SECTION HEADER
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 12),
            child: Row(
              children: [
                const Icon(Icons.play_arrow, color: kGold, size: 14),
                const SizedBox(width: 6),
                Text("TODAY'S TIPS", style: GoogleFonts.barlowCondensed(fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 2)),
              ],
            ),
          ),
        ),

        // TIPS LIST
        StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('tips').snapshots(),
          builder: (ctx, snap) {
            if (!snap.hasData) return const SliverToBoxAdapter(child: Center(child: CircularProgressIndicator(color: kGold)));
            final tips = snap.data!.docs;
            if (tips.isEmpty) {
              return SliverToBoxAdapter(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(40),
                    child: Column(children: [
                      const Text('📋', style: TextStyle(fontSize: 48)),
                      const SizedBox(height: 12),
                      Text('No tips yet today', style: GoogleFonts.barlowCondensed(color: kMuted, fontSize: 16, letterSpacing: 1)),
                    ]),
                  ),
                ),
              );
            }
            return SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 100),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (ctx, i) {
                    final tip = tips[i].data() as Map<String, dynamic>;
                    final isPremium = tip['premium'] ?? false;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 11),
                      child: isPremium && !isPaid
                          ? _lockedCard(tip, ctx)
                          : _tipCard(tip),
                    );
                  },
                  childCount: tips.length,
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _statsRow() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('tips').snapshots(),
      builder: (_, snap) {
        int total = 0, wins = 0, pending = 0;
        if (snap.hasData) {
          total = snap.data!.docs.length;
          for (final d in snap.data!.docs) {
            final data = d.data() as Map<String, dynamic>;
            if (data['result'] == 'win') wins++;
            if (data['result'] == 'pending') pending++;
          }
        }
        final settled = total - pending;
        final rate = settled > 0 ? '${(wins / settled * 100).round()}%' : '—';
        return SizedBox(
          height: 90,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 16),
            children: [
              _statChip('$total', 'Total Tips', kGold),
              _statChip('$wins', 'Won', kGreen),
              _statChip('$pending', 'Pending', kGold),
              _statChip(rate, 'Win Rate', kGold2),
            ],
          ),
        );
      },
    );
  }

  Widget _statChip(String num, String label, Color color) {
    return Container(
      margin: const EdgeInsets.only(right: 10),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kGold.withOpacity(0.15)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(num, style: GoogleFonts.blackOpsOne(fontSize: 20, color: color)),
          const SizedBox(height: 2),
          Text(label, style: GoogleFonts.barlowCondensed(fontSize: 10, letterSpacing: 2, color: kMuted)),
        ],
      ),
    );
  }

  Widget _tipCard(Map<String, dynamic> tip) {
    final result = tip['result'] ?? 'pending';
    Color rColor = kGold;
    String rLabel = '⏳ PENDING';
    if (result == 'win') { rColor = kGreen; rLabel = '✓ WIN'; }
    if (result == 'loss') { rColor = kRed; rLabel = '✗ LOSS'; }

    return Container(
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kGold.withOpacity(0.15)),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
            child: Row(
              children: [
                Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(
                    color: kGold.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: kGold.withOpacity(0.2)),
                  ),
                  child: Center(child: Text(tip['sport'] ?? '⚽', style: const TextStyle(fontSize: 18))),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tip['match'] ?? '', style: GoogleFonts.barlowCondensed(fontSize: 16, fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis),
                      Text(tip['league'] ?? '', style: GoogleFonts.barlow(fontSize: 11, color: kMuted)),
                    ],
                  ),
                ),
                if (tip['premium'] == true)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [kGold, kGold2]),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text('PRO', style: GoogleFonts.barlowCondensed(fontSize: 9, letterSpacing: 2, fontWeight: FontWeight.w700, color: Colors.black)),
                  ),
              ],
            ),
          ),
          Divider(color: Colors.white.withOpacity(0.04), height: 1),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('PREDICTION', style: GoogleFonts.barlowCondensed(fontSize: 10, letterSpacing: 2, color: kMuted)),
                      Text(tip['prediction'] ?? tip['odds'] ?? '', style: GoogleFonts.barlowCondensed(fontSize: 15, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: kGold.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: kGold.withOpacity(0.25)),
                  ),
                  child: Text(tip['odds'] ?? '', style: GoogleFonts.blackOpsOne(fontSize: 15, color: kGold)),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                    color: rColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: rColor.withOpacity(0.3)),
                  ),
                  child: Text(rLabel, style: GoogleFonts.barlowCondensed(fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.w700, color: rColor)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _lockedCard(Map<String, dynamic> tip, BuildContext ctx) {
    return GestureDetector(
      onTap: () => _showPayment(ctx),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF131320),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kGold.withOpacity(0.07)),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
              child: Row(
                children: [
                  Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.04), borderRadius: BorderRadius.circular(10)),
                    child: const Center(child: Icon(Icons.lock, color: kMuted, size: 18)),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Premium Tip', style: GoogleFonts.barlowCondensed(fontSize: 16, fontWeight: FontWeight.w700, color: kMuted)),
                        Text(tip['league'] ?? '', style: GoogleFonts.barlow(fontSize: 11, color: kMuted.withOpacity(0.5))),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    decoration: BoxDecoration(gradient: const LinearGradient(colors: [kGold, kGold2]), borderRadius: BorderRadius.circular(5)),
                    child: Text('PRO', style: GoogleFonts.barlowCondensed(fontSize: 9, letterSpacing: 2, fontWeight: FontWeight.w700, color: Colors.black)),
                  ),
                ],
              ),
            ),
            Divider(color: Colors.white.withOpacity(0.04), height: 1),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.lock_outline, color: kMuted, size: 16),
                  const SizedBox(width: 6),
                  Text('Unlock PRO to view this tip', style: GoogleFonts.barlowCondensed(fontSize: 13, color: kMuted, letterSpacing: 1)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── PAYMENT SHEET ─────────────────────────────────────────
class PaymentSheet extends StatelessWidget {
  const PaymentSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF12121A),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
        border: Border.all(color: kGold.withOpacity(0.15)),
      ),
      padding: const EdgeInsets.fromLTRB(22, 16, 22, 40),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(width: 38, height: 4, decoration: BoxDecoration(color: Colors.white.withOpacity(0.12), borderRadius: BorderRadius.circular(2))),
          ),
          const SizedBox(height: 22),
          Text('Unlock PRO Access', style: GoogleFonts.blackOpsOne(fontSize: 20, letterSpacing: 2, color: kGold)),
          const SizedBox(height: 5),
          Text('Get full access to all premium tips. Follow the steps below.', style: GoogleFonts.barlow(fontSize: 13, color: kMuted, height: 1.5)),
          const SizedBox(height: 20),
          _step('1', 'Send Payment via Mobile Money', 'Send your subscription fee to our Mobile Money number and screenshot your receipt.'),
          const SizedBox(height: 9),
          _step('2', 'Contact Admin', 'Send your receipt and registered email to admin via WhatsApp or SMS for verification.'),
          const SizedBox(height: 9),
          _step('3', 'Get Activated', 'Admin will activate your PRO account within minutes and all premium tips unlock immediately.'),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              style: TextButton.styleFrom(
                backgroundColor: kDark3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kGold.withOpacity(0.15))),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text('CLOSE', style: GoogleFonts.barlowCondensed(fontSize: 14, letterSpacing: 3, color: kMuted)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _step(String num, String title, String desc) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: kDark3,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.04)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 26, height: 26,
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [kGold, kGold2]), shape: BoxShape.circle),
            child: Center(child: Text(num, style: GoogleFonts.blackOpsOne(fontSize: 12, color: Colors.black))),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: GoogleFonts.barlowCondensed(fontSize: 14, letterSpacing: 1, color: kGold)),
                const SizedBox(height: 3),
                Text(desc, style: GoogleFonts.barlow(fontSize: 12, color: kMuted, height: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
